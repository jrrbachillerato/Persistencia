using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APIGestionFicheros
{
    public enum opcionGestor : byte { AgregarNombre = 1, MostrarListado, ComprobarNombre, EliminarNombre, ObtenerNombreAleatorio }
    public static class APIFicheros
    {
        // CONFIGURACIÓN ESTÁTICA DEL SISTEMA DE FICHEROS
        const string FICHERO = "Nombres.nom";
        const string TEMPORAL = "Nombres.tmp";

        #region MÉTODOS PÚBLICOS

        /// <summary>
        /// Agrega un nombre al fichero si no existe ya.
        /// </summary>
        /// <exception cref="ArgumentNullException">Si el nombre está vacío.</exception>
        /// <exception cref="OverflowException">Si el nombre ya está registrado.</exception>
        public static void AgregarNombre(string nombre)
        {
            // RECURSOS
            StreamWriter escritor = null;

            // 1 - Validar nombre
            if (string.IsNullOrWhiteSpace(nombre)) throw new ArgumentNullException("El nombre está vacío.");

            // 2 - Comprobar si existe el fichero y determinar el modo de apertura
            if (File.Exists(FICHERO))
            {
                // 3 - Comprobar si el nombre ya existe
                if (ExisteNombre(nombre))
                {
                    throw new OverflowException($"ERROR, el nombre '{nombre}' ya está registrado.");
                }
                escritor = File.AppendText(FICHERO);
            }
            else
            {
                // El fichero no existe: se crea
                escritor = File.CreateText(FICHERO);
            }

            // 4 - Escribir en fichero
            escritor.WriteLine(nombre);

            // 5 - Cerrar StreamWriter
            escritor.Close();
        }

        /// <summary>
        /// Elimina un nombre del fichero usando un fichero temporal.
        /// </summary>
        /// <exception cref="ArgumentNullException">Si el nombre está vacío.</exception>
        /// <exception cref="FileNotFoundException">Si el fichero no existe.</exception>
        /// <exception cref="KeyNotFoundException">Si el nombre no está registrado.</exception>
        public static void EliminarNombre(string nombre)
        {
            // RECURSOS
            string[] listaNombres;
            StreamWriter escritorTemporal = null;

            // 1.- Validar el nombre
            if (string.IsNullOrWhiteSpace(nombre)) throw new ArgumentNullException("El nombre está vacío.");

            // 2.- Comprobar si existe el fichero
            if (!File.Exists(FICHERO))
                throw new FileNotFoundException("No existe el fichero de nombres.");

            // 3.- Comprobar si existe el nombre
            if (!ExisteNombre(nombre))
                throw new KeyNotFoundException($"El nombre '{nombre}' no está registrado.");

            listaNombres = ObtenerListadoArray();

            // 3.1.- Creación del fichero temporal
            escritorTemporal = File.CreateText(TEMPORAL);

            // 3.2.- Copiar todos los nombres excepto el eliminado
            for (int i = 0; i < listaNombres.Length; i++)
            {
                if (!string.Equals(listaNombres[i], nombre, StringComparison.OrdinalIgnoreCase))
                {
                    escritorTemporal.WriteLine(listaNombres[i]);
                }
            }

            // 3.3.- Cerrar el StreamWriter
            escritorTemporal.Close();

            // 3.4.- Eliminar el fichero original
            File.Delete(FICHERO);

            // 3.5.- Renombrar el temporal como el original
            File.Move(TEMPORAL, FICHERO);
        }

        /// <summary>
        /// Devuelve un array con todos los nombres registrados, o null si el fichero no existe.
        /// </summary>
        public static string[] ObtenerListadoArray()
        {
            // RECURSOS
            string[] listaNombres = null;

            // 1.- Obtener la lista si existe el fichero
            if (File.Exists(FICHERO))
            {
                listaNombres = File.ReadAllLines(FICHERO);
            }

            return listaNombres;
        }

        /// <summary>
        /// Devuelve un array con todos los nombres usando StreamReader y List, o null si el fichero no existe.
        /// </summary>
        public static string[] ObtenerListadoColeccion()
        {
            // RECURSOS
            string[] listaNombres = null;
            List<string> coleccionNombres = null;
            StreamReader lector = null;
            string nombreLeido = null;

            // 1.- Comprobar si existe el fichero
            if (File.Exists(FICHERO))
            {
                // 2.- Instanciar la colección
                coleccionNombres = new List<string>();

                // 3.- Abrir el fichero en modo lectura
                lector = File.OpenText(FICHERO);

                // 4.- Leer todo el fichero
                while (lector.Peek() != -1)
                {
                    nombreLeido = lector.ReadLine();
                    coleccionNombres.Add(nombreLeido);
                }

                lector.Close();

                // 5.- Convertir la colección a array  ← CORRECCIÓN: faltaba esta línea
                listaNombres = coleccionNombres.ToArray();
            }

            return listaNombres;
        }

        /// <summary>
        /// Comprueba si un nombre existe en el fichero.
        /// </summary>
        /// <exception cref="ArgumentNullException">Si el nombre está vacío.</exception>
        public static bool ExisteNombre(string nombre)
        {
            // RECURSOS
            bool encontrado = false;
            StreamReader lector = null;

            // 1 - Validar Nombre
            if (string.IsNullOrWhiteSpace(nombre)) throw new ArgumentNullException("ERROR, No has introducido ningún dato.");

            // 2 - Comprobar si existe el fichero
            if (File.Exists(FICHERO))
            {
                // 3 - Abrir en modo lectura y buscar
                lector = File.OpenText(FICHERO);
                encontrado = BuscarNombre(nombre, lector);
                lector.Close();
            }

            return encontrado;
        }

        /// <summary>
        /// Devuelve un nombre aleatorio del fichero, o null si el fichero no existe o está vacío.
        /// </summary>
        public static string ObtenerNombreAleatorio()
        {
            // RECURSOS
            string[] listaNombres = ObtenerListadoArray();
            string nombreAleatorio = null;

            if (listaNombres != null && listaNombres.Length > 0)
            {
                Random rnd = new Random();
                int indice = rnd.Next(0, listaNombres.Length);
                nombreAleatorio = listaNombres[indice];
            }

            return nombreAleatorio;
        }

        #endregion

        #region MÉTODOS PRIVADOS

        private static bool BuscarNombre(string nombre, StreamReader lector)
        {
            // RECURSOS
            bool encontrado = false;
            string nombreRegistrado = null;

            while (!encontrado && lector.Peek() != -1)
            {
                nombreRegistrado = lector.ReadLine();
                encontrado = string.Equals(nombreRegistrado, nombre, StringComparison.OrdinalIgnoreCase);
            }

            return encontrado;
        }

        #endregion
    }
}
