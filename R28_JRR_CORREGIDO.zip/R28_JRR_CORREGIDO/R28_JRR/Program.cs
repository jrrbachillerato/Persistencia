﻿namespace R28_JRR
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ControladorPr.IniciarPrograma();
        }
    }
}
