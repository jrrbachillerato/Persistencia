using APIGestionFicheros;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R28_JRR
{
    public static class ControladorPr
    {
        public static void IniciarPrograma()
        {
            // RECURSOS
            opcionGestor accion = opcionGestor.AgregarNombre;
            bool repetir = false;

            // 1 - Bienvenida al programa
            Interfaz.Bienvenida();

            do
            {
                // 2 - Mostrar menú y obtener selección
                accion = Interfaz.ObtenerAccion();

                // 3 - Realizar acción
                switch (accion)
                {
                    case opcionGestor.AgregarNombre:
                        AgregarNombres();
                        break;
                    case opcionGestor.MostrarListado:
                        MostrarListado();
                        break;
                    case opcionGestor.ComprobarNombre:
                        ComprobarNombre();
                        break;
                    case opcionGestor.EliminarNombre:
                        EliminarNombre();
                        break;
                    case opcionGestor.ObtenerNombreAleatorio:
                        ObtenerNombreAleatorio();
                        break;
                }

                repetir = Interfaz.SolicitarConfirmacion();
            }
            while (repetir);

            // 4.- Despedida
            Interfaz.Despedida();
        }

        private static void AgregarNombres()
        {
            // RECURSOS
            string nombre;
            bool noError = true;
            string mensajeError = null;

            // 1.- Solicitar nombre
            nombre = Interfaz.SolicitarNombre();

            // 2.- Agregar nombre al fichero
            try
            {
                APIFicheros.AgregarNombre(nombre);
            }
            catch (ArgumentNullException error)
            {
                noError = false;
                mensajeError = error.Message;
            }
            catch (OverflowException error)
            {
                noError = false;
                mensajeError = error.Message;
            }
            catch (Exception error)
            {
                noError = false;
                mensajeError = error.Message;
            }
            finally
            {
                if (!noError)
                {
                    Interfaz.MostrarMensaje(mensajeError);
                }
            }
        }

        private static void MostrarListado()
        {
            // RECURSOS
            string[] listaNombres = null;

            // 1.- Obtener el listado
            listaNombres = APIFicheros.ObtenerListadoArray();

            // 2.- Mostrar el listado
            Interfaz.MostrarListado(listaNombres);
        }

        private static void ComprobarNombre()
        {
            // RECURSOS
            string nombre;
            bool encontrado = false;
            bool noError = true;
            string mensajeError = null;

            // 1.- Solicitar nombre
            nombre = Interfaz.SolicitarNombre();

            // 2.- Comprobar si existe
            try
            {
                encontrado = APIFicheros.ExisteNombre(nombre);
            }
            catch (ArgumentNullException error)
            {
                noError = false;
                mensajeError = error.Message;
            }
            catch (Exception error)
            {
                noError = false;
                mensajeError = error.Message;
            }
            finally
            {
                if (!noError)
                {
                    Interfaz.MostrarMensaje(mensajeError);
                }
            }

            // 3.- Mostrar resultado (solo si no hubo error)
            if (noError)
            {
                Interfaz.MostrarResultadoBusqueda(nombre, encontrado);
            }
        }

        private static void EliminarNombre()
        {
            // RECURSOS
            string nombre;
            bool noError = true;
            string mensajeError = null;

            // 1.- Solicitar nombre
            nombre = Interfaz.SolicitarNombre();

            // 2.- Eliminar nombre del fichero
            try
            {
                APIFicheros.EliminarNombre(nombre);
            }
            catch (ArgumentNullException error)
            {
                noError = false;
                mensajeError = error.Message;
            }
            catch (FileNotFoundException error)
            {
                noError = false;
                mensajeError = error.Message;
            }
            catch (KeyNotFoundException error)
            {
                noError = false;
                mensajeError = error.Message;
            }
            catch (Exception error)
            {
                noError = false;
                mensajeError = error.Message;
            }
            finally
            {
                if (!noError)
                {
                    Interfaz.MostrarMensaje(mensajeError);
                }
            }
        }

        private static void ObtenerNombreAleatorio()
        {
            // RECURSOS
            string nombre = null;
            bool noError = true;
            string mensajeError = null;

            // 1.- Obtener nombre aleatorio
            try
            {
                nombre = APIFicheros.ObtenerNombreAleatorio();
            }
            catch (Exception error)
            {
                noError = false;
                mensajeError = error.Message;
            }
            finally
            {
                if (!noError)
                {
                    Interfaz.MostrarMensaje(mensajeError);
                }
            }

            // 2.- Mostrar resultado
            if (noError)
            {
                Interfaz.MostrarNombreAleatorio(nombre);
            }
        }
    }
}
