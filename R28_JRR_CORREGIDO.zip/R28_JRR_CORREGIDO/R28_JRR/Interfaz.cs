using APIGestionFicheros;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R28_JRR
{
    public static class Interfaz
    {
        public static void Bienvenida()
        {
            Console.WriteLine("=== GESTOR DE NOMBRES ===\n");
            Console.WriteLine("Bienvenido\n");
        }

        public static opcionGestor ObtenerAccion()
        {
            // RECURSOS
            opcionGestor opcion = opcionGestor.AgregarNombre;
            byte seleccion = 0;
            bool esCorrecto = false;
            string mensaje = null;

            do
            {
                Console.Clear();
                esCorrecto = true;

                Console.WriteLine("Seleccione la acción a realizar\n");
                Console.WriteLine("1 - Agregar Nombre\n2 - Mostrar Listado de Nombres\n3 - Comprobar Nombre\n4 - Eliminar Nombre\n5 - Obtener Nombre aleatorio\n");

                try
                {
                    seleccion = Convert.ToByte(Console.ReadLine());
                    opcion = (opcionGestor)seleccion;

                    if (!Enum.IsDefined(typeof(opcionGestor), opcion))
                    {
                        throw new ArgumentException("La opción no está en lista.");
                    }
                }
                catch (FormatException error)
                {
                    esCorrecto = false;
                    mensaje = error.Message;
                }
                catch (ArgumentNullException error)
                {
                    esCorrecto = false;
                    mensaje = error.Message;
                }
                catch (OverflowException error)
                {
                    esCorrecto = false;
                    mensaje = error.Message;
                }
                catch (Exception error)
                {
                    esCorrecto = false;
                    mensaje = error.Message;
                }
                finally
                {
                    if (!esCorrecto)
                    {
                        MostrarMensaje(mensaje);
                    }
                }
            }
            while (!esCorrecto);

            return opcion;
        }

        public static void MostrarMensaje(string mensaje)
        {
            Console.Clear();
            Console.WriteLine(mensaje);
            Console.WriteLine("\nPulse ENTER para continuar...");
            Console.ReadLine();
            Console.Clear();
        }

        public static string SolicitarNombre()
        {
            // RECURSOS
            string nombre = "";
            bool esCorrecto = false;

            do
            {
                Console.Clear();
                esCorrecto = true;

                Console.WriteLine("Introduzca el nombre:");
                try
                {
                    nombre = Console.ReadLine();

                    if (string.IsNullOrWhiteSpace(nombre))
                        throw new ArgumentNullException("No ha introducido ningún nombre.");
                }
                catch (ArgumentNullException error)
                {
                    esCorrecto = false;
                    MostrarMensaje(error.Message);
                }
                catch (Exception)
                {
                    esCorrecto = false;
                    MostrarMensaje("Ha ocurrido un error inesperado.");
                }
            }
            while (!esCorrecto);

            return nombre;
        }

        public static void MostrarListado(string[] listaNombres)
        {
            Console.Clear();

            if (listaNombres == null || listaNombres.Length == 0)
            {
                Console.WriteLine("No hay nombres registrados.");
            }
            else
            {
                Console.WriteLine($"=== LISTADO DE NOMBRES ({listaNombres.Length}) ===\n");
                for (int i = 0; i < listaNombres.Length; i++)
                {
                    Console.WriteLine($"  {i + 1}. {listaNombres[i]}");
                }
            }

            Console.WriteLine("\nPulse ENTER para continuar...");
            Console.ReadLine();
        }

        public static void MostrarResultadoBusqueda(string nombre, bool encontrado)
        {
            Console.Clear();

            if (encontrado)
                Console.WriteLine($"El nombre '{nombre}' SÍ está registrado.");
            else
                Console.WriteLine($"El nombre '{nombre}' NO está registrado.");

            Console.WriteLine("\nPulse ENTER para continuar...");
            Console.ReadLine();
        }

        public static void MostrarNombreAleatorio(string nombre)
        {
            Console.Clear();

            if (string.IsNullOrEmpty(nombre))
                Console.WriteLine("No hay nombres registrados para seleccionar.");
            else
                Console.WriteLine($"Nombre aleatorio obtenido: {nombre}");

            Console.WriteLine("\nPulse ENTER para continuar...");
            Console.ReadLine();
        }

        public static void Despedida()
        {
            Console.Clear();
            Console.WriteLine("Gracias por usar la app. ¡Hasta pronto!");
        }

        public static bool SolicitarConfirmacion()
        {
            bool confirmar = true;
            bool correcto = false;   // CORRECCIÓN: inicializar a false para entrar al bucle
            char letra = ' ';
            string mensaje = "";

            do
            {
                Console.Clear();
                correcto = true;

                Console.WriteLine("¿Desea realizar otra operación? - S/N");
                try
                {
                    string entrada = Console.ReadLine();

                    if (string.IsNullOrEmpty(entrada))
                        throw new FormatException("No ha introducido ningún carácter.");

                    letra = Convert.ToChar(entrada.Trim().ToUpper()[0]);
                }
                catch (Exception error)
                {
                    correcto = false;
                    mensaje = error.Message;
                    MostrarMensaje(mensaje);
                    continue;   // Volver al inicio del bucle sin evaluar la letra
                }

                if (letra == 'S') confirmar = true;
                else if (letra == 'N') confirmar = false;
                else
                {
                    correcto = false;
                    Console.WriteLine("Opción no válida. Por favor, introduzca S o N.");
                    Console.WriteLine("\nPulse ENTER para continuar...");
                    Console.ReadLine();
                }
            }
            while (!correcto);

            return confirmar;
        }
    }
}
